window.addEventListener('mousemove', function (e) {
var cursorX = e.x
var cursorY = e.y
var middleX = screen.width / 2
var middleY = screen.height / 2
var useDirection = character.getAttribute("use")
var usingToggle = false

if (screen.height - cursorY < middleY) {
    character.setAttribute("use", "down")
//alert("down")
}

  if (screen.width  - cursorX < middleX / 2) {

    character.setAttribute("use", "right")

} if (screen.width - cursorX > middleX) {
     character.setAttribute("use", "left")   }
    
})

if (character.getAttribute("walking") == "true" && character.getAttribute("using") == "true"){

character.setAttribute("using", "false")

}

addEventListener('mousedown', e => {

  })

window.addEventListener('mousemove', function (e) {
var cursorX = e.x
var cursorY = e.y
var middleX = screen.width / 2
var middleY = screen.height / 2
var use = character.getAttribute("use")

  if (screen.height - cursorY < middleY) {
    character.setAttribute("use", "up")
    character.setAttribute("using", "false")   
}


  if (screen.height - cursorY > middleY) {
    character.setAttribute("use", "down")
    character.setAttribute("using", "false")
    
}

  if (screen.width  - cursorX < middleX / 2) {
    character.setAttribute("using", "false")
    character.setAttribute("use", "right")
   

} 
  if (screen.width - cursorX > middleX) {
     character.setAttribute("use", "left")   
     character.setAttribute("using", "false")
}       
 })

var toggled = "false"
function toggle() {

if (toggled == "false") {

character.setAttribute("using", "true")

return toggled = "true"

}

else {

character.setAttribute("using", "false")

return toggled = "false"

}


}
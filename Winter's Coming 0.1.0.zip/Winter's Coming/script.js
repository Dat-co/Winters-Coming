//this is a function for the button settings DONT TOUCH!!!
function defualtButtonSettings(debug, destroy, add) {
 console.log(debug) 
var sfx = {
   push: new Howl({
      src: [
         'files/play.mp3'
      ]
   })

}
sfx.push.play()
$(destroy).hide()
$(add).show()
}


//this is the start button
function start() {
defualtButtonSettings("debug-start","#hub",'#onePlayer',"Home Screen.html")  
}

//this is the  credits button
function credits() {
defualtButtonSettings("debug-credits","#hub")

/* 
   devs- Mason B, Aiden N, Jaden G and Oscar P
   Loding screen- Tashfeen
   Jquery- Jquery Team
   Howler- James Simpson and team
   Tutorials- Drew Conly, red stapler
*/
}

//this is the info button
function info() {
defualtButtonSettings("debug-info","#hub") 
}

//this is the one player button
function onePlayer() {
defualtButtonSettings("debug-onePlayer","#startVerities","","modes/onePlayerMode/onePlayerMode.html")
location.replace("modes/onePlayerMode/onePlayerMode.html")
}

//this is where we put things to start up in js
startUp()
function startUp() {
console.log("debug-On")
}
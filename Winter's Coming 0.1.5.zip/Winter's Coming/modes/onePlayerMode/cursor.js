
//wait for the cursor to move
window.addEventListener('mousemove', function (e) {

//get the values from the event 
var cursorX = e.x
var cursorY = e.y

var middleX = screen.width / 2
var middleY = screen.height / 2
var use = character.getAttribute("use")

//check if closer to the top of the player
  if (screen.height - cursorY < middleY) {
    character.setAttribute("use", "up")
    character.setAttribute("using", "false")   
}

//check if closer to the bottom of the player
  if (screen.height - cursorY > middleY) {
    character.setAttribute("use", "down")
    character.setAttribute("using", "false")
    
}

//check if closer to the right of the player
  if (screen.width  - cursorX < middleX / 2) {
    character.setAttribute("using", "false")
    character.setAttribute("use", "right")
   

} 

//check if closer to the left of the player
  if (screen.width - cursorX > middleX) {
     character.setAttribute("use", "left")   
     character.setAttribute("using", "false")
}       
 })

//toggiling to start animating and to stop
var toggled = "false"

let toggle = () => {

if (toggled == "false") {

character.setAttribute("using", "true")

return toggled = "true"

}

else {

character.setAttribute("using", "false")

return toggled = "false"

}


}
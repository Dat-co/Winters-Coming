
var audio = new Audio('files/play.mp3');

//this is the start button
function start() {
  location.replace("modes/onePlayerMode/onePlayerMode.html")
}

function credits() {
  audio.play();
}

/* 

   devs- Mason B and Eloise D
   
   artists- Aiden N, Jaden G, Oscar P

   beta testers-
      
   special thanks to - Drew Clony

*/

function info() {
   audio.play(); 
}
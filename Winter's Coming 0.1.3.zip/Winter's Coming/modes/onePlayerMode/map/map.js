
function random_set() {

function set_number(num) {

var random_numberb = Math.floor((Math.random() * 2) + 1);
var random_number = random_numberb.toString();

document.getElementsByClassName(num)[0].setAttribute("random-number", random_number)

 }

 set_number("tile-1")

}

random_set()